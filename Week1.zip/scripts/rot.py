#! /usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist

rospy.init_node('move_bot')

pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
rate = rospy.Rate(1)
rot = Twist()

clockwise = int(input("Clockwise?: "))

if clockwise == 1:
	rot.angular.z = 0.5
else:
	rot.angular.z = -0.5

while not rospy.is_shutdown():
	pub.publish(rot)
	rate.sleep()


