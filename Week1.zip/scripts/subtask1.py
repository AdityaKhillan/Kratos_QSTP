#!/usr/bin/env python3

import rospy
from std_msgs.msg import Int32
from std_msgs.msg import String
from geometry_msgs.msg import Twist

class Movebot():
    def __init__(self):
            self.pub = rospy.Publisher('/cmd_vel', Twist,queue_size=1)
            self.move=Twist()
            self.rate=rospy.Rate(2)
            self.state=String()
            self.state="linear"
            if self.state == "angular":
                    self.ang()
            elif self.state == "linear":
                    self.lin()
            else:
                    self.stop()
            self.pub.publish(self.move)
            self.rate.sleep()
    def ang(self):
            self.move.angular.z=0.2
    def lin(self):
            self.move.linear.x=0.2
    def stop(self):
            self.move.linear.x=0.0
            self.move.angular.z=0.0

if __name__ == '__main__':
        rospy.init_node('moveturtlebot')
        try:
                while not rospy.is_shutdown():
                        Movebot()
        except rospy.ROSInterruptException:
            pass
